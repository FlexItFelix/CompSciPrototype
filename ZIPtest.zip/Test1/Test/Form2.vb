﻿Imports System.Drawing

Public Class Form2
    'Graphics Variables
    Dim G As Graphics
    Dim BBG As Graphics
    Dim BB As Bitmap
    Dim r As Rectangle


    ' FPS Counters
    Dim tSec As Integer = TimeOfDay.Second
    Dim tTicks As Integer = 0
    Dim maxTicks As Integer = 0

    ' Game running?
    Dim isRunning As Boolean = True

    'Mouse locations
    Dim mouseX As Integer
    Dim mouseY As Integer
    Dim mMapX As Integer
    Dim mMapY As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Show()
        Me.Focus()

        ' Intialize graphics objects
        G = Me.CreateGraphics
        BB = New Bitmap(750, 550)

        StartGameLoop()
    End Sub

    Private Sub StartGameLoop()
        Do While isRunning = True
            ' Keep app responsive
            Application.DoEvents()

            '1.) Check user input
            '2.) Run AI
            '3.) Update object data (object positions, status, etc.)
            '4.) Check triggers and conditions 
            '5.) Draw graphics
            DrawGraphics()
            '6.) Playing sound effects & music

            ' Update tick counter
            TickCounter()
        Loop
    End Sub

    Private Sub DrawGraphics()
        'Fill the backbuffer (BB)
        'Draw tiles
        For X = 0 To 19
            For Y = 0 To 14
                r = New Rectangle(X * 32, Y * 32, 32, 32)

                G.FillRectangle(Brushes.BurlyWood, r)
                G.DrawRectangle(Pens.Black, r)
            Next
        Next

        ' Draw final layers
        ' Guys, menus, etc.
        G.DrawString("Ticks: " & tTicks & vbCrLf &
                     "TPS:" & maxTicks & vbCrLf &
                     "Mouse X: " & mouseX & vbCrLf &
                     "Mouse Y: " & mouseY & vbCrLf &
                     "", Me.Font, Brushes.Black, 650, 0)

        ' Copy backbuffer (BB) to graphics object
        G = Graphics.FromImage(BB)

        ' Draw backbuffer to screen
        BBG = Me.CreateGraphics
        BBG.DrawImage(BB, 0, 0, 750, 550)

        ' Fix overdraw
        G.Clear(Color.Wheat)
    End Sub

    Private Sub TickCounter()
        If tSec = TimeOfDay.Second And isRunning = True Then
            tTicks = tTicks + 1
        Else
            maxTicks = tTicks
            tTicks = 0
            tSec = TimeOfDay.Second
        End If
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove

        mouseX = Math.Floor(e.X / 32) ' Math.Floor rounds down
        mouseY = Math.Floor(e.Y / 32)


    End Sub
End Class