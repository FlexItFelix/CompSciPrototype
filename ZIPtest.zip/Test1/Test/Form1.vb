﻿Public Class Form1
    Private Sub btnPlayGame_Click(sender As Object, e As EventArgs) Handles btnPlayGame.Click
        Me.Hide()
        Form2.Show()
    End Sub
    Dim question1 As String
    Dim answer1 As String

    Private Sub btnAddQAs_Click(sender As Object, e As EventArgs) Handles btnAddQAs.Click
        Do While question1 <> "Stop"
            question1 = InputBox("Enter Term - Type stop To Stop Entering Questions and Answers.", "Enter Term")
            answer1 = InputBox("Enter Definition", "Enter Definition")

        Loop
    End Sub
End Class
